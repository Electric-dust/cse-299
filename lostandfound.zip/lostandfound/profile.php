<?php 
include 'db_connect.php';
include 'header.php'; 

if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$uid = $_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE user_id = $uid"));

if(isset($_POST['update_profile'])) {
    $name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $update = "UPDATE users SET full_name='$name', phone='$phone' WHERE user_id=$uid";
    if(mysqli_query($conn, $update)) {
        $_SESSION['full_name'] = $name;
        header("Location: profile.php?status=success");
        exit();
    }
}
?>

<main class="report-section">
    <div class="report-container" style="max-width: 600px; margin: 0 auto; display:block;">
        <div class="form-side">
            <h2 class="report-title">My Profile</h2>
            
            <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                <div style="background: #dcfce7; color: #166534; padding: 15px; border-radius: 12px; margin-bottom: 20px; font-weight: 600; text-align: center;">
                    ✅ Profile updated successfully!
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="input-group full-width" style="margin-bottom: 15px;">
                    <label>Full Name</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                <div class="input-group full-width" style="margin-bottom: 15px;">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                </div>
                <div class="input-group full-width" style="margin-bottom: 25px;">
                    <label>Email (Verified)</label>
                    <input type="text" value="<?php echo $user['email']; ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
                </div>
                
                <button type="submit" name="update_profile" class="btn-submit">Save Changes</button>
                
                <hr style="margin: 30px 0; border: 0; border-top: 1px solid #e2e8f0;">
                
                <a href="logout.php" class="btn-gold-small" style="background: #fee2e2; color: #ef4444; width: 100%; display: block; border: none;">
                    Sign Out of Account
                </a>
            </form>
        </div>
    </div>
</main>

<?php include 'footer.php'; ?>