<?php 
session_start();
include 'db_connect.php';

// 1. SECURITY: Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$item_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$current_user_id = $_SESSION['user_id'];

// 2. UPDATE LOGIC: Runs when "Save Changes" is clicked
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_item'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $loc = mysqli_real_escape_string($conn, $_POST['location']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $cat = intval($_POST['category_id']);

    // Check for image update
    $image_update_sql = "";
    if (!empty($_FILES['item_image']['name'])) {
        $target_dir = "uploads/";
        $file_name = time() . "_" . basename($_FILES["item_image"]["name"]);
        $target_file = $target_dir . $file_name;
        
        if (move_uploaded_file($_FILES["item_image"]["tmp_name"], $target_file)) {
            $image_update_sql = ", item_image = '$target_file'";
        }
    }

    $update_query = "UPDATE items SET 
                     title = '$title', 
                     location_name = '$loc', 
                     description = '$desc', 
                     category_id = $cat 
                     $image_update_sql 
                     WHERE item_id = $item_id AND user_id = $current_user_id";

    if (mysqli_query($conn, $update_query)) {
        // Redirect back to details with a success message
        header("Location: details.php?id=$item_id&status=success");
        exit;
    } else {
        $error_msg = "Database Error: " . mysqli_error($conn);
    }
}

// 3. FETCH CURRENT DATA: To fill the form fields
$fetch_sql = "SELECT * FROM items WHERE item_id = $item_id AND user_id = $current_user_id";
$result = mysqli_query($conn, $fetch_sql);
$item = mysqli_fetch_assoc($result);

// If item doesn't exist or doesn't belong to the user, boot them out
if (!$item) {
    die("<div style='margin-top:150px; text-align:center;'><h2>Unauthorized Access</h2><p>You do not have permission to edit this post.</p><a href='index.php'>Back to Home</a></div>");
}

include 'header.php'; 
?>

<style>
    .edit-section { margin-top: 150px; margin-bottom: 100px; padding: 0 10%; }
    .edit-container { background: white; padding: 50px; border-radius: 30px; box-shadow: 0 20px 50px rgba(0,0,0,0.05); }
    .form-group { margin-bottom: 25px; }
    .form-group label { display: block; font-weight: 700; color: #003060; margin-bottom: 10px; text-transform: uppercase; font-size: 0.8rem; }
    .form-group input, .form-group textarea, .form-group select { 
        width: 100%; padding: 15px 25px; border-radius: 50px; border: 1px solid #e2e8f0; outline: none; font-family: inherit; background: #fcfdfe;
    }
    .form-group textarea { border-radius: 20px; resize: none; }
    .btn-row { display: flex; gap: 15px; margin-top: 20px; }
</style>

<div class="edit-section">
    <div class="edit-container">
        <h1 style="color: #003060; margin-bottom: 30px;">Edit Your Report</h1>
        
        <?php if(isset($error_msg)) echo "<p style='color:red;'>$error_msg</p>"; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
                <div class="form-group">
                    <label>Item Name / Title</label>
                    <input type="text" name="title" value="<?php echo htmlspecialchars($item['title']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Exact Location</label>
                    <input type="text" name="location" value="<?php echo htmlspecialchars($item['location_name']); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label>Category</label>
                <select name="category_id">
                    <?php 
                    $cats = mysqli_query($conn, "SELECT * FROM categories");
                    while($c = mysqli_fetch_assoc($cats)) {
                        $selected = ($c['category_id'] == $item['category_id']) ? "selected" : "";
                        echo "<option value='".$c['category_id']."' $selected>".$c['category_name']."</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label>Detailed Description</label>
                <textarea name="description" rows="6" required><?php echo htmlspecialchars($item['description']); ?></textarea>
            </div>

            <div class="form-group">
                <label>Replace Image (Leave empty to keep current)</label>
                <input type="file" name="item_image" style="border-radius: 15px;">
            </div>

            <div class="btn-row">
                <button type="submit" name="update_item" class="btn-gold" style="flex:1; border:none; padding:18px;">Save Changes</button>
                <a href="details.php?id=<?php echo $item_id; ?>" class="btn-gold" style="flex:1; background:#64748b; text-decoration:none;">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>