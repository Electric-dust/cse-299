<?php 
session_start();
include 'db_connect.php';
include 'header.php'; 

// Check if user is already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>

<main class="report-section">
    <div class="report-container" style="max-width: 500px; margin: 0 auto; display: block;">
        <div class="form-side" id="login-form">
            <h2 class="report-title">Sign In</h2>
            <form action="auth_action.php" method="POST" onsubmit="return validateAuth()">
                <div class="input-group full-width" style="margin-bottom:15px;">
                    <label>Email</label>
                    <input type="email" name="email" id="login_email" required>
                </div>
                <div class="input-group full-width" style="margin-bottom:15px;">
                    <label>Password</label>
                    <input type="password" name="password" id="login_pass" required>
                </div>
                <button type="submit" name="login_btn" class="btn-submit">Login</button>
            </form>
            <p style="margin-top:20px; text-align:center;">Don't have an account? <a href="#" onclick="toggleAuth()">Sign Up</a></p>
        </div>

        <div class="form-side" id="signup-form" style="display:none;">
            <h2 class="report-title">Sign Up</h2>
            <form action="auth_action.php" method="POST">
                <div class="input-grid">
                    <div class="input-group full-width"><label>Full Name</label><input type="text" name="full_name" required></div>
                    <div class="input-group"><label>NSU ID</label><input type="text" name="student_id"></div>
                    <div class="input-group"><label>Email</label><input type="email" name="email" required></div>
                    <div class="input-group full-width"><label>Password</label><input type="password" name="password" required></div>
                </div>
                <button type="submit" name="signup_btn" class="btn-submit">Create Account</button>
            </form>
            <p style="margin-top:20px; text-align:center;">Already have an account? <a href="#" onclick="toggleAuth()">Login</a></p>
        </div>
    </div>
</main>

<script>
function toggleAuth() {
    const login = document.getElementById('login-form');
    const signup = document.getElementById('signup-form');
    login.style.display = login.style.display === 'none' ? 'block' : 'none';
    signup.style.display = signup.style.display === 'none' ? 'block' : 'none';
}

function validateAuth() {
    const email = document.getElementById('login_email').value;
    if (!email.includes("@northsouth.edu") && !email.includes("@nsu.edu")) {
        alert("Please use your NSU email address.");
        return false;
    }
    return true;
}
</script>

<?php include 'footer.php'; ?>