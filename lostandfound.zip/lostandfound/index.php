<?php 
include 'db_connect.php';
include 'header.php'; 

$filter_cat = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
?>

<style>
  section {
    position: relative;
    z-index: 1;
}
  /* 1. FORCE HERO TO FULL MONITOR */
.hero {
    min-height: 90vh !important;
    width: 100% !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: center !important;
    align-items: center !important;
    background: radial-gradient(circle at center, #ffffff 0%, #f8fafc 100%) !important;
    position: relative !important;
    overflow: hidden !important;
    border-bottom: 1px solid #f1f5f9;
}
/* Base Floating Icon Styling */
.parallax-icon {
    position: absolute;
    pointer-events: none;
    z-index: 1;
    opacity: 0.6; /* Subtle depth */
    filter: drop-shadow(0 20px 30px rgba(0, 48, 96, 0.34));
    transition: transform 0.1s ease-out;
}

/* --- ENHANCED FULL-SPACE ICONS --- */

/* LEFT SIDE: ID, Taka, Laptop */
.icon-id { 
    top: 10%; 
    left: 12%;  
    width: 200px; /* Bigger */
    animation: float 6s ease-in-out infinite; 
}
.icon-taka { 
    top: 42%; 
    left: 5%;  
    width: 260px; /* Bigger */
    animation: float 7s ease-in-out infinite 1s; 
}
.icon-laptop { 
    bottom: 2%; 
    left: 3%; 
    width: 560px; /* Massive for 3D anchor effect */
    animation: float 8s ease-in-out infinite 2s; 
}

/* RIGHT SIDE: Mobile, Books, Headphone */
.icon-mobile { 
    top: 8%; 
    right: 8%; 
    width: 270px; /* Bigger */
    animation: float 6.5s ease-in-out infinite 0.5s; 
}
.icon-books { 
    top: 45%; 
    right: 3%; 
    width: 260px; /* Bigger */
    animation: float 7.5s ease-in-out infinite 1.5s; 
}
.icon-phone { 
    bottom: 10%; 
    right: 10%; 
    width: 380px; /* Bigger */
    animation: float 8.5s ease-in-out infinite 2.5s; 
}
@keyframes float {
    0%, 100% { margin-top: 0px; }
    50% { margin-top: -20px; }
}

/* Center Content */
.hero h1 {
    font-size: 5.5rem !important;
    font-weight: 900 !important;
    color: #003060;
    z-index: 10;
    margin-bottom: 15px !important;
    letter-spacing: -2px;
}

.hero h1 {
    font-size: 5rem !important; /* Huge impact */
    margin-bottom: 20px !important;
    line-height: 1.1 !important;
}

.hero p {
    font-size: 1.3rem !important;
    margin-bottom: 40px !important;
    color: #64748b !important;
}
#category-filter-area {
    width: 100%;
    max-width: 1300px; /* Increased to cover more area */
    margin: 60px auto;
    padding: 25px 40px; /* More breathing room on the sides */
}

#category-filter-area .section-title {
    font-size: 1.6rem;
    font-weight: 800;
    color: #003060;
    margin-bottom: 40px;
    text-transform: uppercase;
    letter-spacing: 2px;
    text-align: center;
}

/* --- THE WIDE 1x1 GRID --- */
#category-filter-area .category-grid {
    display: grid !important;
    grid-template-columns: repeat(3, 1fr) !important; /* 3 columns across */
    gap: 30px !important;
    width: 100% !important;
}

#category-filter-area .cat-card {
    background: #ffffff !important;
    /* --- MAGIC FOR 1:1 RATIO --- */
    aspect-ratio: 1 / 1 !important; 
    
    width: 100% !important;
    border-radius: 40px !important; /* Larger, smoother corners */
    text-decoration: none !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
    border: 1px solid rgba(0, 0, 0, 0.06) !important;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05) !important;
    color: #003060 !important;
}

#category-filter-area .cat-card:hover {
    transform: translateY(-15px) scale(1.03) !important;
    box-shadow: 0 30px 70px rgba(0, 48, 96, 0.18) !important;
    border-color: #e5a50a !important;
}

#category-filter-area .cat-card.active {
    background: #003060 !important;
    color: #ffffff !important;
    border-color: #003060 !important;
    box-shadow: 0 25px 50px rgba(0, 48, 96, 0.3) !important;
}

#category-filter-area .cat-icon {
    font-size: 5rem !important; /* Even bigger icon for the big squares */
    margin-bottom: 25px !important;
}

#category-filter-area .cat-card span {
    font-weight: 800 !important;
    font-size: 1.3rem !important; /* Bigger text */
    letter-spacing: 0.5px;
}

#category-filter-area .cat-card.active span {
    color: #ffffff !important;
}

/* RESPONSIVE: Stays 1:1 but drops columns */
@media (max-width: 1000px) {
    #category-filter-area .category-grid {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 20px !important;
    }
}

@media (max-width: 600px) {
    #category-filter-area {
        padding: 0 20px;
    }
    #category-filter-area .category-grid {
        grid-template-columns: 1fr !important;
    }
    #category-filter-area .cat-icon {
        font-size: 4rem !important;
    }
}
/* --- HOW IT WORKS DESIGN --- */
#how-it-works {
    background: #ffffff;
    padding: 100px 0;
    text-align: center;
}

.steps-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 40px;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.step-card {
    padding: 40px;
    position: relative;
    border-radius: 24px;
    background: var(--bg-light);
    transition: 0.3s;
}

.step-number {
    font-family: "Outfit", sans-serif;
    font-size: 4rem;
    font-weight: 900;
    color: rgba(0, 48, 96, 0.05); /* Faded NSU Blue */
    position: absolute;
    top: 10px;
    left: 20px;
}

.step-card h3 {
    color: var(--nsu-blue);
    margin-bottom: 15px;
    position: relative;
    font-size: 1.5rem;
}

.step-card p {
    color: var(--text-muted);
    font-size: 1rem;
    line-height: 1.6;
}

/* --- USER EXPERIENCE SECTION --- */
#user-experience {
    padding: 100px 8%;
    background-color: #fcfdfe;
    overflow: hidden;
    position: relative;
    z-index: 1;
    margin-bottom: 80px;
}

.experience-container {
    display: flex;
    gap: 60px;
    align-items: center;
    max-width: 1400px;
    margin: 0 auto;
}

.experience-header {
    flex: 0 0 400px; /* Fixed width for the left side */
}

.badge {
    background: #6382f1; /* Light Blue Badge */
    color: white;
    padding: 6px 16px;
    border-radius: 6px;
    font-size: 0.85rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 25px;
}

.experience-title {
    font-size: 3.5rem;
    color: #003060;
    font-weight: 800;
    margin-bottom: 20px;
    letter-spacing: -1px;
}

.experience-desc {
    color: #64748b;
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 40px;
}

.slider-controls {
    display: flex;
    gap: 15px;
}

.control-btn {
    width: 60px;
    height: 60px;
    background: #fdb913; /* NSU Gold */
    border: none;
    border-radius: 8px;
    color: #003060;
    font-size: 1.5rem;
    cursor: pointer;
    transition: 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.control-btn:hover {
    background: #e5a50a;
    transform: scale(1.05);
}

/* SLIDER CARDS */
.experience-slider {
    display: flex;
    gap: 30px;
    overflow-x: auto;
    padding: 20px;
    scroll-behavior: smooth;
    scrollbar-width: none;
}

.experience-slider::-webkit-scrollbar { display: none; }

.exp-card {
    min-width: 450px;
    background: white;
    padding: 50px;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.03);
    border: 1px solid #f1f5f9;
    position: relative;
    display: flex;
    flex-direction: column;
}

.exp-stars {
    color: #fdb913;
    font-size: 1.5rem;
    margin-bottom: 25px;
}

.exp-text {
    color: #64748b;
    font-size: 1.2rem;
    line-height: 1.8;
    margin-bottom: 40px;
    flex-grow: 1;
}

.exp-footer {
    display: flex;
    align-items: center;
    gap: 15px;
    padding-top: 30px;
    border-top: 1px solid #f1f5f9;
    position: relative;
}

.user-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    background: #eee;
}

.user-info strong {
    display: block;
    color: #003060;
    font-size: 1.1rem;
}

.user-info span {
    color: #94a3b8;
    font-size: 0.9rem;
}

.quote-icon {
    position: absolute;
    right: 0;
    bottom: 20px;
    width: 60px;
    height: 60px;
    background: #f8fafc;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6382f1;
    font-weight: 900;
    font-size: 1.5rem;
    transform: rotate(180deg);
}

/* Responsive */
@media (max-width: 1100px) {
    .experience-container { flex-direction: column; }
    .experience-header { flex: none; width: 100%; text-align: center; }
    .slider-controls { justify-content: center; }
    .exp-card { min-width: 320px; padding: 30px; }
}
/* Moves items lower from category section */
.content-area {
    margin-top: 60px !important; 
    padding-top: 1px;
}

/* Ensures the link doesn't change card appearance */
.card-link {
    text-decoration: none !important;
    color: inherit !important;
    display: block;
}

.card-link:hover .item-name {
    color: var(--nsu-gold); /* Suble hint that it's clickable */
}
</style>

<header class="hero">
    <img src="img/id.png" class="parallax-icon icon-id" alt="ID">
  <img src="img/taka.png" class="parallax-icon icon-taka" alt="Taka">
  <img src="img/laptop.png" class="parallax-icon icon-laptop" alt="Laptop">

  <img src="img/mobile.png" class="parallax-icon icon-mobile" alt="Mobile">
  <img src="img/books.png" class="parallax-icon icon-books" alt="Books">
  <img src="img/headphone.png" class="parallax-icon icon-phone" alt="Headphone">

  <h1>Lost & Found<span>.</span></h1>
  <p>A refined space for the NSU community to find what they've lost.</p>
  <form action="index.php" method="GET" class="search-wrapper">
    <input type="text" name="search" placeholder="Search items..." />
    <button type="submit" class="btn-gold">Search</button>
  </form>
</header>

<section class="category-section" id="category-filter-area">
    <h2 class="section-title">Browse by Category</h2>
    <div class="category-grid">
      <a href="index.php" class="cat-card <?php echo ($filter_cat == 0) ? 'active' : ''; ?>">
        <div class="cat-icon">📂</div>
        <span>View All</span>
      </a>
      <a href="index.php?cat_id=1" class="cat-card <?php echo ($filter_cat == 1) ? 'active' : ''; ?>">
        <div class="cat-icon">🚨</div>
        <span>Emergency</span>
      </a>
      <a href="index.php?cat_id=2" class="cat-card <?php echo ($filter_cat == 2) ? 'active' : ''; ?>">
        <div class="cat-icon">💻</div>
        <span>Electronics</span>
      </a>
      <a href="index.php?cat_id=3" class="cat-card <?php echo ($filter_cat == 3) ? 'active' : ''; ?>">
        <div class="cat-icon">💰</div>
        <span>Wallets/Cash</span>
      </a>
      <a href="index.php?cat_id=4" class="cat-card <?php echo ($filter_cat == 4) ? 'active' : ''; ?>">
        <div class="cat-icon">📚</div>
        <span>Books</span>
      </a>
    </div>
</section>

<main class="content-area">
  <div class="grid">
    <?php
    $search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
    
    $sql = "SELECT items.*, categories.category_name 
            FROM items 
            LEFT JOIN categories ON items.category_id = categories.category_id 
            WHERE 1=1"; 

    if ($filter_cat > 0) {
        $sql .= " AND items.category_id = $filter_cat";
    }
    if (!empty($search)) {
        $sql .= " AND items.title LIKE '%$search%'";
    }

    $sql .= " ORDER BY items.is_emergency DESC, items.created_at DESC";
    
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $isEmergency = ($row['is_emergency'] == 1);
            $tagClass = $isEmergency ? "tag-emergency" : "tag-" . $row['item_type'];
            $imagePath = !empty($row['item_image']) ? $row['item_image'] : 'img/default.jpg';
            ?>
            <a href="details.php?id=<?php echo $row['item_id']; ?>" class="card-link">
    <article class="card">
        <div class="card-image" style="background-image: url('<?php echo $imagePath; ?>'); background-size: cover; background-position: center;"></div>
        <div class="card-body">
            <span class="tag <?php echo $tagClass; ?>"><?php echo ($isEmergency) ? "🚨 Emergency" : ucfirst($row['item_type']); ?></span>
            <h3 class="item-name"><?php echo htmlspecialchars($row['title']); ?></h3>
            <div class="item-loc">📍 <?php echo htmlspecialchars($row['location_name']); ?></div>
        </div>
    </article>
</a>
            <?php 
        }
    } else {
        echo "<p style='grid-column: 1/-1; text-align: center; margin-top: 40px;'>No items found in this category.</p>";
    }
    ?>
  </div>
</main>
<section id="how-it-works">
    <div class="container">
        <h2 class="section-title">How NSU Recovery Works</h2>
        <div class="steps-grid">
            <div class="step-card">
                <div class="step-number">01</div>
                <h3>Report Item</h3>
                <p>Lost something or found an item? Submit a report with a photo and location details.</p>
            </div>
            <div class="step-card">
                <div class="step-number">02</div>
                <h3>Quick Verification</h3>
                <p>Our system categorizes the item and flags emergency documents (ID cards) immediately.</p>
            </div>
            <div class="step-card">
                <div class="step-number">03</div>
                <h3>Secure Retrieval</h3>
                <p>Connect with the finder and arrange a safe meetup at a designated NSU campus point.</p>
            </div>
        </div>
    </div>
</section>

<section id="user-experience">
    <div class="experience-container">
        <div class="experience-header">
            <span class="badge">What our users say</span>
            <h2 class="experience-title">User Experience</h2>
            <p class="experience-desc">
                We are on a mission to help people find what they have lost and report what they have found.
            </p>
            <div class="slider-controls">
                <button class="control-btn" onclick="document.querySelector('.experience-slider').scrollBy({left: -350, behavior: 'smooth'})">←</button>
                <button class="control-btn" onclick="document.querySelector('.experience-slider').scrollBy({left: 350, behavior: 'smooth'})">→</button>
            </div>
        </div>

        <div class="experience-slider">
            <div class="exp-card">
                <div class="exp-stars">⭐⭐⭐⭐⭐</div>
                <p class="exp-text">
                    I lost my wallet and uploaded it on Lost & Found. Within hours, someone who found it shared it on the platform, and I got it back safely. It’s amazing how simple and fast the process is!
                </p>
                <div class="exp-footer">
                    <img src="img/user1.jpg" alt="User" class="user-avatar">
                    <div class="user-info">
                        <strong>H. M. Hafizur Rahman</strong>
                        <span>Accounts Manager</span>
                    </div>
                    <div class="quote-icon">99</div>
                </div>
            </div>

            <div class="exp-card">
                <div class="exp-stars">⭐⭐⭐⭐</div>
                <p class="exp-text">
                    The categorization system is very helpful. I found my lost keys near the library by just filtering the location. Great initiative for the NSU community!
                </p>
                <div class="exp-footer">
                    <img src="img/user2.jpg" alt="User" class="user-avatar">
                    <div class="user-info">
                        <strong>Sarah Tanvir</strong>
                        <span>Student, CSE</span>
                    </div>
                    <div class="quote-icon">99</div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    #chat-wrapper { position: fixed; bottom: 30px; right: 30px; z-index: 9999; font-family: 'Outfit', sans-serif; }
    #chat-window { 
        display: none; width: 350px; height: 450px; background: white; 
        border-radius: 20px; flex-direction: column; box-shadow: 0 15px 50px rgba(0,0,0,0.2); 
        border: 1px solid #eee; overflow: hidden; margin-bottom: 15px;
    }
    #chat-header { background: #003060; color: white; padding: 20px; font-weight: 800; display: flex; justify-content: space-between; }
    #chat-body { flex: 1; padding: 15px; overflow-y: auto; background: #fcfdfe; font-size: 0.95rem; }
    #chat-footer { padding: 15px; border-top: 1px solid #eee; display: flex; gap: 10px; background: white; }
    #chat-input { flex: 1; border: none; outline: none; font-size: 0.9rem; }
    .bot-msg { background: #f1f5f9; color: #003060; padding: 10px 15px; border-radius: 15px 15px 15px 0; margin-bottom: 10px; width: fit-content; max-width: 80%; }
    .user-msg { background: #fdb913; color: #003060; padding: 10px 15px; border-radius: 15px 15px 0 15px; margin-bottom: 10px; margin-left: auto; width: fit-content; max-width: 80%; }
    #chat-toggle { 
        width: 65px; height: 65px; background: #fdb913; border-radius: 50%; 
        border: none; cursor: pointer; box-shadow: 0 8px 20px rgba(253, 185, 19, 0.4); 
        display: flex; align-items: center; justify-content: center; font-size: 1.8rem; transition: 0.3s;
    }
    #chat-toggle:hover { transform: scale(1.1); }
</style>

<div id="chat-wrapper">
    <div id="chat-window">
        <div id="chat-header">
            <span>NSU AI Assistant</span>
            <button onclick="toggleChat()" style="background:none; border:none; color:white; cursor:pointer;">✕</button>
        </div>
        <div id="chat-body">
            <div class="bot-msg">Hi! Ask me if we've found your lost item. 🔍</div>
        </div>
        <div id="chat-footer">
            <input type="text" id="chat-input" placeholder="Search for my wallet..." onkeypress="if(event.key === 'Enter') sendToAI()">
            <button onclick="sendToAI()" style="background:#003060; color:white; border:none; padding:8px 15px; border-radius:8px; cursor:pointer;">Send</button>
        </div>
    </div>
    <button id="chat-toggle" onclick="toggleChat()">🤖</button>
</div>

<script>
function toggleChat() {
    const window = document.getElementById('chat-window');
    window.style.display = (window.style.display === 'none' || window.style.display === '') ? 'flex' : 'none';
}

async function sendToAI() {
    const input = document.getElementById('chat-input');
    const body = document.getElementById('chat-body');
    const text = input.value.trim();

    if (!text) return;

    // 1. Add User Message
    body.innerHTML += `<div class="user-msg">${text}</div>`;
    input.value = '';
    body.scrollTop = body.scrollHeight;

    // 2. Add Loading Message
    const loadingId = "load-" + Date.now();
    body.innerHTML += `<div class="bot-msg" id="${loadingId}"><i>Thinking...</i></div>`;

    try {
        const response = await fetch('chat_engine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text })
        });

        const data = await response.json();
        document.getElementById(loadingId).remove();

        if (data.choices && data.choices[0]) {
            const aiReply = data.choices[0].message.content;
            body.innerHTML += `<div class="bot-msg">${aiReply}</div>`;
        } else {
            body.innerHTML += `<div class="bot-msg" style="color:red;">API error. Check token.</div>`;
        }
    } catch (err) {
        document.getElementById(loadingId).remove();
        body.innerHTML += `<div class="bot-msg" style="color:red;">Server error. Try again.</div>`;
    }
    body.scrollTop = body.scrollHeight;
}
document.addEventListener('mousemove', (e) => {
    const icons = document.querySelectorAll('.parallax-icon');
    const x = (window.innerWidth / 2 - e.pageX) / 45;
    const y = (window.innerHeight / 2 - e.pageY) / 45;

    icons.forEach((icon, index) => {
        const depth = (index + 1) * 0.6;
        icon.style.transform = `translate3d(${x * depth}px, ${y * depth}px, 0)`;
    });
});
</script>
<?php include 'footer.php'; ?>