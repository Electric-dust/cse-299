<?php 
include 'db_connect.php';
include 'header.php'; 

// Get the current category from URL
$current_cat = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
?>

<style>
/* --- EXPLORE LAYOUT --- */
.explore-wrapper {
    display: flex;
    margin-top: 100px; /* Space for fixed header */
    min-height: 100vh;
    background: #f8fafc;
}

/* --- SIDEBAR STICKY --- */
.sidebar {
    width: 300px;
    background: white;
    padding: 40px 30px;
    border-right: 1px solid #e2e8f0;
    position: sticky;
    top: 80px; /* Sticks below your navbar */
    height: calc(100vh - 80px);
}

.sidebar h2 {
    font-size: 1.4rem;
    color: #003060;
    margin-bottom: 30px;
    font-weight: 800;
}

.category-list {
    list-style: none;
    padding: 0;
}

.category-list li {
    margin-bottom: 10px;
}

.category-list a {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    text-decoration: none;
    color: #64748b;
    border-radius: 15px;
    font-weight: 600;
    transition: 0.3s;
}

.category-list a:hover {
    background: #f1f5f9;
    color: #003060;
}

.category-list a.active {
    background: #003060;
    color: white;
    box-shadow: 0 10px 20px rgba(0, 48, 96, 0.15);
}

.cat-dot {
    width: 8px;
    height: 8px;
    background: #fdb913;
    border-radius: 50%;
    margin-right: 15px;
}

/* --- MAIN CONTENT AREA --- */
.explore-content {
    flex: 1;
    padding: 40px 5%;
}

.explore-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px;
}

.explore-header h1 {
    font-size: 2rem;
    color: #003060;
}

/* --- GRID SYSTEM --- */
.item-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 30px;
}

/* Reuse your existing Card styling here */
.card-link { text-decoration: none; color: inherit; }
.card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    transition: 0.3s;
    border: 1px solid #eee;
}
.card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(0,0,0,0.1); }
.card-image { height: 180px; background-size: cover; background-position: center; }
.card-body { padding: 20px; }

/* Responsive Sidebar */
@media (max-width: 900px) {
    .explore-wrapper { flex-direction: column; }
    .sidebar { width: 100%; height: auto; position: relative; top: 0; }
}
</style>

<div class="explore-wrapper">
    <aside class="sidebar">
        <h2>Categories</h2>
        <ul class="category-list">
            <li>
                <a href="explore.php" class="<?php echo ($current_cat == 0) ? 'active' : ''; ?>">
                    <div class="cat-dot"></div> View All
                </a>
            </li>
            <?php 
            $cats = mysqli_query($conn, "SELECT * FROM categories");
            while($c = mysqli_fetch_assoc($cats)) {
                $activeClass = ($current_cat == $c['category_id']) ? 'active' : '';
                echo "<li>
                        <a href='explore.php?cat_id=".$c['category_id']."' class='$activeClass'>
                            <div class='cat-dot'></div> ".$c['category_name']."
                        </a>
                      </li>";
            }
            ?>
        </ul>
    </aside>

    <main class="explore-content">
        <div class="explore-header">
            <h1>Discovery Hub</h1>
            <span style="color: #64748b; font-weight: 500;">
                Showing: <?php echo ($current_cat == 0) ? 'All Items' : 'Filtered Results'; ?>
            </span>
        </div>

        <div class="item-grid">
            <?php
            // Filter Logic
            $sql = "SELECT * FROM items WHERE 1=1";
            if ($current_cat > 0) {
                $sql .= " AND category_id = $current_cat";
            }
            $sql .= " ORDER BY created_at DESC";
            
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    $img = !empty($row['item_image']) ? $row['item_image'] : 'img/default.jpg';
                    ?>
                    <a href="details.php?id=<?php echo $row['item_id']; ?>" class="card-link">
                        <article class="card">
                            <div class="card-image" style="background-image: url('<?php echo $img; ?>');"></div>
                            <div class="card-body">
                                <span class="tag"><?php echo strtoupper($row['item_type']); ?></span>
                                <h3 style="margin: 10px 0; color: #003060;"><?php echo htmlspecialchars($row['title']); ?></h3>
                                <div style="color: #64748b; font-size: 0.9rem;">📍 <?php echo htmlspecialchars($row['location_name']); ?></div>
                            </div>
                        </article>
                    </a>
                    <?php
                }
            } else {
                echo "<p style='text-align:center; grid-column: 1/-1;'>No items found in this category.</p>";
            }
            ?>
        </div>
    </main>
</div>

<?php include 'footer.php'; ?>