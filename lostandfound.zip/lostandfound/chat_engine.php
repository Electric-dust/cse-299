<?php
// 1. SILENCE PHP ERRORS (They break JSON responses)
error_reporting(0);
ini_set('display_errors', 0);

include 'db_connect.php';
header('Content-Type: application/json');

// 2. INPUT CHECK
$input = file_get_contents("php://input");
$decode = json_decode($input, true);
$userMessage = $decode['message'] ?? '';

if (empty($userMessage)) {
    echo json_encode(["choices" => [["message" => ["content" => "Type a message!"]]]]);
    exit;
}

// 3. DATABASE CONTEXT
$items_context = "Items at NSU: ";
$query = "SELECT title, location_name FROM items ORDER BY created_at DESC LIMIT 5";
$result = mysqli_query($conn, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $items_context .= $row['title'] . " (at " . $row['location_name'] . "), ";
    }
}

// 4. GROK API SETUP (Using your verified token & model)
$apiKey = "xai-SM3cnH6yjK2n7lklI3s4HlfxbMez6xERptPAhbzxqYWToMbkN2sAnsvuWU9R1Jmpn6clUkMcycJZ0eU4";
$apiUrl = "https://api.x.ai/v1/chat/completions";

$postData = [
    "model" => "grok-4-1-fast",
    "messages" => [
        ["role" => "system", "content" => "You are an assistant for NSU Recovery. List: " . $items_context],
        ["role" => "user", "content" => $userMessage]
    ],
    "stream" => false
];

// 5. THE REQUEST
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer " . $apiKey
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// 6. SMART ERROR HANDLING
if ($curlError) {
    echo json_encode(["choices" => [["message" => ["content" => "Server Connection Error: " . $curlError]]]]);
} elseif ($httpCode !== 200) {
    // If Grok rejects us, show the RAW error from Grok
    $rawError = json_decode($response, true);
    $msg = $rawError['error']['message'] ?? "Unknown API Error (Code: $httpCode)";
    echo json_encode(["choices" => [["message" => ["content" => "Grok Error: " . $msg]]]]);
} else {
    // Success!
    echo $response;
}