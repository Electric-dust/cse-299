<?php
// 1. Start the session at the very top of the file
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NSU Recovery | Premium Lost & Found</title>

    <link
      href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&family=Plus+Jakarta+Sans:wght@300;400;500;700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/style.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  </head>
  <body>
    <nav>
      <a href="index.php" class="logo">NSU<span>RECOVERY</span></a>

      <div class="nav-links">
        <a href="explore.php">Explore</a>

        <?php if (isset($_SESSION['user_id'])): ?>
          <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="admin_dashboard.php" style="color: var(--nsu-gold);">Admin Panel</a>
          <?php endif; ?>

          <a href="report.php" class="btn-gold" style="padding: 10px 20px;">Report Item</a>

          <a href="profile.php" class="profile-link" title="My Profile">
            <div style="
              width: 42px; 
              height: 42px; 
              background: var(--nsu-blue); 
              border: 2px solid var(--nsu-gold);
              border-radius: 50%; 
              display: flex; 
              align-items: center; 
              justify-content: center; 
              color: white; 
              font-weight: 800;
              text-transform: uppercase;
              font-family: 'Outfit', sans-serif;
              transition: 0.3s;
            ">
              <?php 
                // Display first letter of user's name
                echo substr($_SESSION['full_name'], 0, 1); 
              ?>
            </div>
          </a>

        <?php else: ?>
          <a href="login.php" class="btn-gold" style="padding: 10px 20px;">Report Item</a>
          
          <a href="login.php" class="btn-gold-small">Sign In</a>
        <?php endif; ?>
      </div>
    </nav>