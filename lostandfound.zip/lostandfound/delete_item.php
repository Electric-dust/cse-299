<?php
session_start();
include 'db_connect.php';

// 1. Check if the user is even logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: You must be logged in to delete a post. <a href='login.php'>Login here</a>");
}

// 2. Get the ID and User ID
// We use 'id' because that's what we put in the URL: delete_item.php?id=...
$id_to_delete = isset($_GET['id']) ? intval($_GET['id']) : 0;
$current_user = $_SESSION['user_id'];

if ($id_to_delete === 0) {
    die("Error: No valid Item ID provided.");
}

// 3. SECURE DELETE: Only delete if BOTH item_id and user_id match
// This prevents people from deleting other students' posts
$sql = "DELETE FROM items WHERE item_id = $id_to_delete AND user_id = $current_user";

if (mysqli_query($conn, $sql)) {
    // Check if a row was actually removed
    if (mysqli_affected_rows($conn) > 0) {
        // Success! Redirect to home
        header("Location: index.php?msg=deleted_successfully");
        exit;
    } else {
        // This happens if the ID exists but belongs to someone else (or doesn't exist at all)
        die("Error: You do not have permission to delete this post, or the post does not exist.");
    }
} else {
    // This catches database errors (like a wrong column name)
    die("Database Error: " . mysqli_error($conn));
}
?>