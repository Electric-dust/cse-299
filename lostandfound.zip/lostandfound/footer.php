<style>
/* ===== FOOTER MAIN ===== */
footer {
    background: #003060;
    color: #ffffff;
    padding: 60px 8% 30px;
    font-family: 'Outfit', sans-serif;
}

/* ===== HORIZONTAL LAYOUT (FIXED) ===== */
footer .footer-grid {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: flex-start;
    gap: 50px;
    flex-wrap: nowrap; /* keeps horizontal */
}

/* ===== COLUMN SIZES ===== */
footer .footer-brand {
    flex: 2;
}

footer .footer-column {
    flex: 1;
}

/* ===== BRAND ===== */
.footer-brand h2 {
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 15px;
}

.footer-brand h2 span {
    color: #fdb913;
}

.footer-brand p {
    color: #cbd5e1;
    line-height: 1.6;
    font-size: 0.95rem;
}

/* ===== COLUMN LINKS ===== */
.footer-column h4 {
    margin-bottom: 15px;
    font-size: 1.1rem;
    color: #fdb913;
}

.footer-column ul {
    list-style: none;
    padding: 0;
}

.footer-column ul li {
    margin-bottom: 10px;
}

.footer-column ul li a {
    text-decoration: none;
    color: #e2e8f0;
    font-size: 0.95rem;
    transition: 0.3s ease;
}

.footer-column ul li a:hover {
    color: #fdb913;
    padding-left: 5px;
}

/* ===== BOTTOM BAR ===== */
.footer-bottom {
    border-top: 1px solid rgba(255,255,255,0.1);
    margin-top: 40px;
    padding-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.85rem;
    color: #94a3b8;
}

/* ===== RESPONSIVE (MOBILE) ===== */
@media (max-width: 900px) {
    footer .footer-grid {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }

    footer .footer-brand,
    footer .footer-column {
        flex: none;
        width: 100%;
    }

    .footer-bottom {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }
}
</style>

<footer>
    <div class="footer-container">
        <div class="footer-column">
            <div class="footer-logo">NSU RECOVERY<span>.</span></div>
            <p class="footer-desc">
                The official Lost & Found hub for North South University. We help our community reconnect with their misplaced belongings through a secure and verified platform.
            </p>
        </div>

        <div class="footer-column">
            <h4>Quick Links</h4>
            <ul class="footer-links">
                <li><a href="index.php">Home / Feed</a></li>
                <li><a href="report.php">Report an Item</a></li>
                <li><a href="index.php?cat_id=1">Emergency Items</a></li>
                <li><a href="#">My Activity</a></li>
            </ul>
        </div>

        <div class="footer-column">
            <h4>Campus Hub</h4>
            <ul class="footer-links">
                <li><a href="#">📍 Plot 15, Block B, Bashundhara</a></li>
                <li><a href="mailto:support@nsu-recovery.com">✉️ support@nsu-recovery.com</a></li>
                <li><a href="#">📞 NSU Security Ext: 1122</a></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <div>
            &copy; <?php echo date("Y"); ?> <strong>NSU Recovery</strong>. <span class="nsu-tag">CSE299 PROJECT</span>
        </div>
        <div style="letter-spacing: 1px;">
            DESIGNED FOR THE NSU COMMUNITY
        </div>
    </div>
</footer>