<?php
session_start();
include 'db_connect.php';

if(isset($_POST['submit_report'])) {
    $uid = $_SESSION['user_id'];
    $cat = $_POST['category'];
    $type = $_POST['report_type'];
    $title = mysqli_real_escape_string($conn, $_POST['item_name']);
    $loc = mysqli_real_escape_string($conn, $_POST['location']);
    
    // Emergency Detection (Category ID 1 is Emergency)
    $is_emergency = ($cat == 1) ? 1 : 0;

    // Image Upload
    $img_name = time() . "_" . $_FILES['item_image']['name'];
    move_uploaded_file($_FILES['item_image']['tmp_name'], "uploads/" . $img_name);
    $path = "uploads/" . $img_name;

    $query = "INSERT INTO items (user_id, category_id, item_type, title, location_name, item_image, is_emergency) 
              VALUES ('$uid', '$cat', '$type', '$title', '$loc', '$path', '$is_emergency')";
    
    if(mysqli_query($conn, $query)) {
        header("Location: index.php?success=posted");
    }
}
?>