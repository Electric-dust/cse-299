<?php
session_start();
include 'db_connect.php';

if(isset($_POST['signup_btn'])) {
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sid = $_POST['student_id'];

    $sql = "INSERT INTO users (full_name, email, password, student_id) VALUES ('$name', '$email', '$pass', '$sid')";
    if(mysqli_query($conn, $sql)) { header("Location: login.php?msg=success"); }
}

if(isset($_POST['login_btn'])) {
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $res = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    $user = mysqli_fetch_assoc($res);

    if($user && password_verify($pass, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        header("Location: index.php");
    } else {
        header("Location: login.php?error=invalid");
    }
}
?>