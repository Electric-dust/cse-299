<?php include 'header.php'; 
// Redirect if not logged in
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
?>

<main class="report-section">
    <h1 class="report-title">Submit a Report</h1>
    <form action="process_report.php" method="POST" enctype="multipart/form-data">
        <div class="report-container">
            <div class="upload-side" onclick="document.getElementById('file-input').click()">
                <div class="upload-icon">📸</div>
                <div class="upload-text">Click to Upload Photo</div>
                <input type="file" id="file-input" name="item_image" style="display:none;" required>
            </div>

            <div class="form-side">
                <div class="input-grid">
                    <div class="input-group">
                        <label>Report Type</label>
                        <select name="report_type">
                            <option value="lost">I Lost Something</option>
                            <option value="found">I Found Something</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label>Category</label>
                        <select name="category" style="border: 2px solid var(--nsu-gold);">
                            <option value="1">🚨 EMERGENCY (IDs / Docs)</option>
                            <option value="2">Electronics</option>
                            <option value="3">Wallets/Money</option>
                            <option value="4">Books</option>
                            <option value="5">Others</option>
                        </select>
                    </div>

                    <div class="input-group full-width">
                        <label>Item Name</label>
                        <input type="text" name="item_name" placeholder="e.g. Blue NSU ID Card" required>
                    </div>

                    <div class="input-group">
                        <label>Location</label>
                        <input type="text" name="location" placeholder="e.g. Library 4th Floor" required>
                    </div>

                    <div class="input-group">
                        <label>Date</label>
                        <input type="date" name="report_date" required>
                    </div>

                    <div class="input-group full-width">
                        <label>Description</label>
                        <textarea name="description" rows="3"></textarea>
                    </div>
                </div>
                <button type="submit" name="submit_report" class="btn-submit">Post Report</button>
            </div>
        </div>
    </form>
</main>

<?php include 'footer.php'; ?>