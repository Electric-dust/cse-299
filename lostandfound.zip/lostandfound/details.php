<?php 
session_start();
include 'db_connect.php';
include 'header.php'; 

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$current_user_id = $_SESSION['user_id'] ?? null;

// Fetch item with category and owner info
$query = "SELECT items.*, categories.category_name 
          FROM items 
          LEFT JOIN categories ON items.category_id = categories.category_id 
          WHERE items.item_id = $id"; 

$result = mysqli_query($conn, $query);
$item = mysqli_fetch_assoc($result);

if (!$item) { 
    echo "<div style='margin-top:150px; text-align:center;'><h2>Item Not Found</h2><a href='index.php'>Back Home</a></div>";
    include 'footer.php'; exit; 
}

// Ownership Check
$is_owner = ($current_user_id && $current_user_id == $item['user_id']);
$imagePath = !empty($item['item_image']) ? $item['item_image'] : 'img/default.jpg';
?>

<style>
.details-wrapper { margin-top: 150px; margin-bottom: 100px; padding: 0 8%; }
.details-container { display: grid; grid-template-columns: 1fr 1fr; background: white; border-radius: 30px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.05); }
.details-image { width: 100%; height: 600px; background-size: cover; background-position: center; }
.details-info { padding: 60px; }
.description-box { background: #f8fafc; padding: 30px; border-radius: 20px; margin: 25px 0; line-height: 1.8; }
.action-bar { display: flex; gap: 15px; margin-top: 30px; }
</style>

<div class="details-wrapper">
    <div class="details-container">
        <div class="details-image" style="background-image: url('<?php echo $imagePath; ?>');"></div>
        
        <div class="details-info">
            <span class="tag tag-<?php echo $item['item_type']; ?>"><?php echo strtoupper($item['item_type']); ?></span>
            <h1 style="font-size: 2.8rem; color: #003060; margin: 10px 0;"><?php echo htmlspecialchars($item['title']); ?></h1>
            
            <p>📍 <strong>Location:</strong> <?php echo htmlspecialchars($item['location_name']); ?></p>
            <p>📅 <strong>Posted on:</strong> <?php echo date('M d, Y', strtotime($item['created_at'])); ?></p>

            <div class="description-box">
                <h4 style="color:#003060; margin-bottom:10px;">Item Description</h4>
                <p><?php echo nl2br(htmlspecialchars($item['description'])); ?></p>
            </div>

            <div class="action-bar">
                <a href="index.php" class="btn-gold" style="background:#64748b;">Back</a>
                
                <?php if ($is_owner): ?>
                    <a href="edit_item.php?id=<?php echo $item['item_id']; ?>" class="btn-gold">Edit Post</a>
                    <a href="delete_item.php?id=<?php echo $item['item_id']; ?>" 
                       class="btn-gold" 
                       style="background: #dc2626;" 
                       onclick="return confirm('Strictly delete this record?');">Delete</a>
                <?php else: ?>
                    <a href="mailto:contact@nsu.edu?subject=Found: <?php echo $item['title']; ?>" class="btn-gold">Contact Finder</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>