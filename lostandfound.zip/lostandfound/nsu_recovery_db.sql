-- 1. Create the Database
CREATE DATABASE IF NOT EXISTS nsu_recovery_db;
USE nsu_recovery_db;

-- 2. USERS TABLE
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    student_id VARCHAR(20) UNIQUE,
    department VARCHAR(50),
    role ENUM('student', 'admin') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. CATEGORIES TABLE
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL
);

-- 4. ITEMS TABLE (Updated for Emergency Logic)
CREATE TABLE items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT,
    item_type ENUM('lost', 'found') NOT NULL, 
    title VARCHAR(150) NOT NULL,
    description TEXT,
    location_name VARCHAR(255),
    item_image VARCHAR(255),
    event_date DATE,
    -- NEW: is_emergency allows you to highlight or pulse these cards in CSS
    is_emergency BOOLEAN DEFAULT FALSE, 
    is_recovered BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
);

-- 5. CLAIMS TABLE
CREATE TABLE claims (
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    claimer_id INT NOT NULL,
    proof_details TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (claimer_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 6. INITIAL DATA SEEDING (Updated with Emergency)
INSERT INTO categories (category_name) VALUES 
('Emergency (IDs & Documents)'), -- This will likely be ID 1 now
('Electronics'), 
('Wallets & Cash'), 
('Books & Stationery'), 
('Personal Accessories'), 
('Other Items');

-- Add a default Admin
INSERT INTO users (full_name, email, password, role, student_id) 
VALUES ('System Admin', 'admin@nsu.edu', '$2y$10$e0MYzXy..', 'admin', '0000000');