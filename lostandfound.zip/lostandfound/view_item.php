<?php 
include 'db_connect.php';
include 'header.php'; 

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$query = mysqli_query($conn, "SELECT items.*, categories.category_name FROM items 
                               LEFT JOIN categories ON items.category_id = categories.category_id 
                               WHERE id = $id");
$item = mysqli_fetch_assoc($query);

if (!$item) { echo "<p>Item not found.</p>"; exit; }
?>

<div class="report-section">
    <div class="report-container">
        <div class="upload-side" style="background-image: url('<?php echo $item['item_image']; ?>'); background-size: cover;">
            <?php if(empty($item['item_image'])) echo "No Image Available"; ?>
        </div>
        <div class="form-side">
            <span class="tag tag-<?php echo $item['item_type']; ?>"><?php echo strtoupper($item['item_type']); ?></span>
            <h1 class="report-title"><?php echo htmlspecialchars($item['title']); ?></h1>
            <hr style="margin: 20px 0; opacity: 0.1;">
            
            <p><strong>Location:</strong> <?php echo htmlspecialchars($item['location_name']); ?></p>
            <p><strong>Category:</strong> <?php echo htmlspecialchars($item['category_name']); ?></p>
            <p style="margin-top: 20px; color: #64748b;"><?php echo nl2br(htmlspecialchars($item['description'])); ?></p>
            
            <a href="index.php" class="btn-gold" style="margin-top: 30px;">← Back to List</a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>